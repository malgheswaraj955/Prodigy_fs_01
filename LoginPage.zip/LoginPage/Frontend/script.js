const BASE_URL = "http://localhost:5000/api/v1/users";

// Elements
const loginBox = document.getElementById("login-box");
const registerBox = document.getElementById("register-box");
const msg = document.getElementById("msg");

// Toggle forms
function toggleForms() {
  loginBox.classList.toggle("hidden");
  registerBox.classList.toggle("hidden");
}

// Register
async function register() {
  const fullname = document.getElementById("fullname").value;
  const email = document.getElementById("email").value;
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  try {
    const res = await fetch(`${BASE_URL}/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ fullname, email, username, password })
    });

    const data = await res.json().catch(() => ({})); // fallback if invalid JSON

    msg.innerText = data.message || (res.ok ? "Registration successful" : "Registration failed");
    msg.style.color = res.ok ? "green" : "red";

    if (res.ok) toggleForms(); // show login after successful register
  } catch (err) {
    console.error("Register error:", err);
    msg.innerText = "Registration failed";
    msg.style.color = "red";
  }
}


// Login
async function login() {
  const username = document.getElementById("login-username").value;
  const password = document.getElementById("login-password").value;

  try {
    const res = await fetch(`${BASE_URL}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ username, password })
    });
    
    const data = await res.json();

    if (res.ok) {
  msg.innerText = data.message || "Login successful";
  msg.style.color = "green";
  // small delay to ensure cookie is stored before redirect
  setTimeout(() => {
    window.location.href = "dashboard.html";
  }, 300); // 0.3 second delay
}
else {
      msg.innerText = data.message || "Login failed";
      msg.style.color = "red";
    }

  } catch (err) {
    msg.innerText = "Login failed";
    msg.style.color = "red";
  }
}


// Logout
async function logout() {
  await fetch(`${BASE_URL}/logout`, {
    method: "POST",
    credentials: "include"
  });
  window.location.href = "index.html";
}


// On dashboard, set username
if (document.getElementById("welcome")) {
  fetch(`${BASE_URL}/me`, {
    method: "GET",
    credentials: "include"
  })
    .then(res => res.json())
    .then(data => {
      document.getElementById("welcome").innerText = `Welcome, ${data.user.username}!`;
    })
    .catch(() => {
      window.location.href = "index.html"; // redirect to login if not logged in
    });
}
