import express from "express";

const app = express();

// JSON parser
app.use(express.json());

app.post("/test", (req, res) => {
  console.log("Received req.body:", req.body); // <-- debug line
  res.json({ received: req.body });
});

app.listen(5000, () => console.log("Test server running on http://localhost:5000"));
